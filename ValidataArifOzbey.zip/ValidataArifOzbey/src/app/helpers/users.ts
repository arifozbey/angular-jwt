export class Users {
  firstname!:string;
  lastname!:string;
  email!:string;
  password!:string;
  roleid!:number;
}
