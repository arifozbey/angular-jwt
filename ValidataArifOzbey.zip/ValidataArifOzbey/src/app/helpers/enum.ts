enum roleType {
  Admin = '1',
  Manager = '2',
  Editor = '3',
}
